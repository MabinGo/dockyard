package controller

import (
	"encoding/json"
	"net/http"

	"github.com/astaxie/beego/logs"
	"gopkg.in/macaron.v1"

	"github.com/containerops/dockyard/auth/authn"
	"github.com/containerops/dockyard/auth/dao"
)

//1.user manager
//SignUp  POST
//SignIn  POST
//SignOut GET
//ResetPassword  POST
//UpdatePassword POST

//POST
func SignUp(ctx *macaron.Context, log *logs.BeeLogger) (int, []byte) {
	body, err := ctx.Req.Body().Bytes()
	if err != nil {
		log.Error("[SignUp] Failed to get body: %v", err.Error())
		return http.StatusBadRequest, []byte("Request signup message body error")
	}

	u := dao.User{}
	if err := json.Unmarshal(body, &u); err != nil {
		log.Error("[SignUp] Failed to unmarshal request body: %v", err.Error())
		return http.StatusBadRequest, []byte("Failed to unmarshal request body")
	}
	//status and role can't be set by user
	u.Status = 0
	u.Role = dao.SYSMEMBER
	if err := u.Save(); err != nil {
		log.Error("[SignUp] Failed to save user to db: %v", err.Error())
		return ConvertError(err)
	}
	return http.StatusOK, []byte("")
}

//GET
func SignIn(ctx *macaron.Context, log *logs.BeeLogger) (int, []byte) {
	userName, password, _ := ctx.Req.BasicAuth()
	user, err := authn.Login(userName, password)
	if err != nil {
		log.Error("[SignIn] Failed to login: %v", err.Error())
		return http.StatusUnauthorized, []byte("User or pwd error")
	}

	u := map[string]interface{}{
		"name":     user.Name,
		"email":    user.Email,
		"realname": user.RealName,
		"comment":  user.Comment,
		"status":   user.Status,
		"Role":     user.Role,
	}
	if result, err := json.Marshal(u); err != nil {
		log.Error("[SignIn] Failed to marshal user: %v", err.Error())
		return http.StatusInternalServerError, []byte(err.Error())
	} else {
		return http.StatusOK, result
	}
}

//GET
func SignOut(ctx *macaron.Context, log *logs.BeeLogger) (int, []byte) {
	return http.StatusOK, []byte("")

}

//PUT
func UpdatePassword(ctx *macaron.Context, log *logs.BeeLogger) (int, []byte) {
	return http.StatusOK, []byte("")
}

//GET
func ResetPassword(ctx *macaron.Context, log *logs.BeeLogger) (int, []byte) {
	return http.StatusOK, []byte("")
}

//GET
func ActiveUser(ctx *macaron.Context, log *logs.BeeLogger) (int, []byte) {
	return http.StatusOK, []byte("")
}

func UpdateUser(ctx *macaron.Context, log *logs.BeeLogger) (int, []byte) {
	//authn login user
	userName, password, _ := ctx.Req.BasicAuth()
	user, err := authn.Login(userName, password)
	if err != nil {
		log.Error("[Update User] Failed to login: %v", err.Error())
		return http.StatusUnauthorized, []byte(err.Error())
	}

	body, err := ctx.Req.Body().Bytes()
	if err != nil {
		log.Error("[Update User] Failed to get body: %v", err.Error())
		return http.StatusBadRequest, []byte("Request signup message body error")
	}

	//get update field
	var dat map[string]interface{}
	if err := json.Unmarshal(body, &dat); err != nil {
		log.Error("[Update User] Failed to unmarshal request body: %v", err.Error())
		return http.StatusBadRequest, []byte("Failed to unmarshal request body")
	}

	fields := []string{}
	u := &dao.User{}
	if val, ok := dat["name"]; ok {
		u.Name = val.(string)
	}
	if val, ok := dat["email"]; ok {
		u.Email = val.(string)
		fields = append(fields, "email")
	}
	if val, ok := dat["realname"]; ok {
		u.RealName = val.(string)
		fields = append(fields, "realname")
	}
	if val, ok := dat["comment"]; ok {
		u.Comment = val.(string)
		fields = append(fields, "comment")
	}
	if val, ok := dat["password"]; ok {
		u.Password = val.(string)
		fields = append(fields, "password")
		fields = append(fields, "salt")
	}

	if user.Role == dao.SYSADMIN || userName == u.Name {
	} else {
		log.Error("[Update User] Unauthorized to update user info")
		return http.StatusUnauthorized, []byte("Unauthorized to update user info")
	}

	if err := u.Update(fields...); err != nil {
		log.Error("[Update User] Failed to update user info to db: %v", err.Error())
		return ConvertError(err)
	}
	return http.StatusOK, []byte("")
}
